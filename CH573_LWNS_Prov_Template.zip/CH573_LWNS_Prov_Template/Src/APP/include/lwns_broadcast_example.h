/*
 * lwns_broadcast_example.h
 *
 *  Created on: Jul 19, 2021
 *      Author: WCH
 */

#ifndef _LWNS_BROADCAST_EXAMPLE_H_
#define _LWNS_BROADCAST_EXAMPLE_H_

#include "WCH_LWNS_LIB.h"


#define BROADCAST_EXAMPLE_TX_PERIOD_EVT                 1<<(0)

void lwns_broadcast_process_init(void);

#endif /* LWNS_BROADCAST_EXAMPLE_H_ */
