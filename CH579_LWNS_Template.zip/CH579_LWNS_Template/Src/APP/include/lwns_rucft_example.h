/*
 * lwns_rucft_example.h
 *
 *  Created on: Jul 19, 2021
 *      Author: WCH
 */

#ifndef _LWNS_RUCFT_EXAMPLE_H_
#define _LWNS_RUCFT_EXAMPLE_H_

#include "WCH_LWNS_LIB.h"

#define RUCFT_EXAMPLE_TX_PERIOD_EVT                 1<<(0)


void lwns_rucft_process_init(void);
#endif /* _LWNS_RUCFT_EXAMPLE_H_ */
